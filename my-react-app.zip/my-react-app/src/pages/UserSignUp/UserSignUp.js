import React from "react";
import Form from "../../components/Form";
import "./UserSignUp.css";

const UserSignUp = () =>
	<div>
		<Form />
	</div>

export default UserSignUp;